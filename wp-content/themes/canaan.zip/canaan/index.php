<?php
if (!defined('ABSPATH')) {
    die();
}

get_header();
?>

<!-- <div class="max-w-[1420px] mx-auto">
    <?php 
    // get_template_part('lp-home-page/our-studios');
     ?>
</div> -->

<?php

get_footer();
