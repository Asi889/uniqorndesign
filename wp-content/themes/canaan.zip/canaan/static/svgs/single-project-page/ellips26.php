<?php
?>



<svg class="" width="97" height="90" viewBox="0 0 97 90" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g filter="url(#filter0_dii_84_6354)">
        <path d="M76.1776 29.1557C76.1776 45.2579 65.8445 50 49.7423 50C33.64 50 21.1147 40.2375 20.0599 29.1557C19.0502 18.547 30.9197 0 47.0219 0C63.1242 0 76.1776 13.0534 76.1776 29.1557Z" fill="url(#paint0_linear_84_6354)" />
    </g>
    <defs>
        <filter id="filter0_dii_84_6354" x="-8.60842" y="-21.4563" width="104.786" height="111.456" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dy="20" />
            <feGaussianBlur stdDeviation="10" />
            <feComposite in2="hardAlpha" operator="out" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.831373 0 0 0 0 0.0196078 0 0 0 0 0.360784 0 0 0 0.2 0" />
            <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_84_6354" />
            <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_84_6354" result="shape" />
            <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dx="-28.6084" dy="-21.4563" />
            <feGaussianBlur stdDeviation="30" />
            <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.831373 0 0 0 0 0.0196078 0 0 0 0 0.360784 0 0 0 0.2 0" />
            <feBlend mode="normal" in2="shape" result="effect2_innerShadow_84_6354" />
            <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dx="20" dy="20" />
            <feGaussianBlur stdDeviation="20" />
            <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.992157 0 0 0 0 0.764706 0 0 0 0 0.862745 0 0 0 1 0" />
            <feBlend mode="normal" in2="effect2_innerShadow_84_6354" result="effect3_innerShadow_84_6354" />
        </filter>
        <linearGradient id="paint0_linear_84_6354" x1="18.0104" y1="15.9375" x2="96.4825" y2="24.1842" gradientUnits="userSpaceOnUse">
            <stop stop-color="#E8C4FE" />
            <stop offset="1" stop-color="#FDC3DC" />
        </linearGradient>
    </defs>
</svg>