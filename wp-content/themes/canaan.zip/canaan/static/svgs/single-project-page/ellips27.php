<?php
?>

<!-- <svg width="250" height="252" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path opacity=".3" d="M230.284 193.154c-29.381 58.181-74.193 73.219-134.436 45.115C35.605 210.164 3.755 164.803.298 102.184-3.159 39.565 23.507 5.791 80.293.86 137.08-4.07 183.62 12.2 219.915 49.673c36.294 37.473 39.75 85.3 10.369 143.481Z" fill="#BB51FC" />
</svg> -->

<svg width="180" height="162" viewBox="0 0 180 162" fill="none" xmlns="http://www.w3.org/2000/svg">
<g opacity="0.6" filter="url(#filter0_dii_84_7460)">
<path d="M20 58.3641C20 13.2779 45.751 0 85.8794 0C126.008 0 157.222 27.3351 159.851 58.3641C162.367 88.0685 132.128 122 91.9999 122C51.8716 122 20 103.45 20 58.3641Z" fill="url(#paint0_linear_84_7460)"/>
</g>
<defs>
<filter id="filter0_dii_84_7460" x="-8.60842" y="-21.4563" width="211.518" height="183.456" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dy="20"/>
<feGaussianBlur stdDeviation="10"/>
<feComposite in2="hardAlpha" operator="out"/>
<feColorMatrix type="matrix" values="0 0 0 0 0.819608 0 0 0 0 0.541176 0 0 0 0 0.992157 0 0 0 0.2 0"/>
<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_84_7460"/>
<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_84_7460" result="shape"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dx="-28.6084" dy="-21.4563"/>
<feGaussianBlur stdDeviation="35.7605"/>
<feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
<feColorMatrix type="matrix" values="0 0 0 0 0.533333 0 0 0 0 0.0117647 0 0 0 0 0.854902 0 0 0 1 0"/>
<feBlend mode="normal" in2="shape" result="effect2_innerShadow_84_7460"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dx="42.9126" dy="14.3042"/>
<feGaussianBlur stdDeviation="53.6408"/>
<feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
<feColorMatrix type="matrix" values="0 0 0 0 0.909804 0 0 0 0 0.768627 0 0 0 0 0.996078 0 0 0 1 0"/>
<feBlend mode="normal" in2="effect2_innerShadow_84_7460" result="effect3_innerShadow_84_7460"/>
</filter>
<linearGradient id="paint0_linear_84_7460" x1="115.92" y1="143.242" x2="-46.7203" y2="110.223" gradientUnits="userSpaceOnUse">
<stop stop-color="#FFC7E3"/>
<stop offset="1" stop-color="#DD81FF"/>
</linearGradient>
</defs>
</svg>