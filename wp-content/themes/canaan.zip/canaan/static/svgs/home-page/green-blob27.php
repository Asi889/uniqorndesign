<?php
?>

<svg width="140" height="230" fill="none" xmlns="http://www.w3.org/2000/svg">
  <g opacity=".6" filter="url(#aq)">
    <path d="M-93 79C-93 17.972-53.838 0 7.19 0c61.027 0 108.498 37 112.496 79 3.827 40.207-41.159 110.5-102.186 110.5C-43.528 189.5-93 140.027-93 79Z" fill="url(#bq)"/>
  </g>
  <defs>
    <linearGradient id="bq" x1="127.454" y1="129.097" x2="-169.956" y2="97.842" gradientUnits="userSpaceOnUse">
      <stop stop-color="#C0EECA"/>
      <stop offset="1" stop-color="#8EBFFF"/>
    </linearGradient>
    <filter id="aq" x="-121.608" y="-21.456" width="284.434" height="250.956" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
      <feFlood flood-opacity="0" result="BackgroundImageFix"/>
      <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
      <feOffset dy="20"/>
      <feGaussianBlur stdDeviation="10"/>
      <feComposite in2="hardAlpha" operator="out"/>
      <feColorMatrix values="0 0 0 0 0.0745098 0 0 0 0 0.278431 0 0 0 0 0.117647 0 0 0 0.2 0"/>
      <feBlend in2="BackgroundImageFix" result="effect1_dropShadow_68_1364"/>
      <feBlend in="SourceGraphic" in2="effect1_dropShadow_68_1364" result="shape"/>
      <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
      <feOffset dx="-28.608" dy="-21.456"/>
      <feGaussianBlur stdDeviation="35.761"/>
      <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
      <feColorMatrix values="0 0 0 0 0.0745098 0 0 0 0 0.278431 0 0 0 0 0.117647 0 0 0 1 0"/>
      <feBlend in2="shape" result="effect2_innerShadow_68_1364"/>
      <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
      <feOffset dx="42.913" dy="14.304"/>
      <feGaussianBlur stdDeviation="53.641"/>
      <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
      <feColorMatrix values="0 0 0 0 0.505882 0 0 0 0 0.866667 0 0 0 0 0.584314 0 0 0 1 0"/>
      <feBlend in2="effect2_innerShadow_68_1364" result="effect3_innerShadow_68_1364"/>
    </filter>
  </defs>
</svg>
