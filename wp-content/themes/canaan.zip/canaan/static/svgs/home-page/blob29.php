<?php
?>


<svg width="543" height="516" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g opacity=".4" filter="url(#aa1)">
        <path d="M523.001 75c0 60.774-57.988 196.864-118.74 197.993a15.67 15.67 0 0 1-1.517-.052C387.306 271.723 140.781 251.606 134 208.5 115 175 102.304-1 163.331-1c61.028 0 359.67 14.973 359.67 76Z" fill="url(#bb1)" />
        <path d="M233.521 147c0 61.027-39.866 48.633-99.521 61.5C83 219.5 24.833 189 20.835 147 17.008 106.793 72.972 65 134 65c61.027 0 99.521 20.972 99.521 82Z" fill="url(#cc1)" />
        <path d="M355.147 409c0 61.027-40.973 67-102 67-61.028 0-93.503-55-97.501-97-3.827-40.207 36.473-75.5 97.501-75.5 61.027 0 102 44.473 102 105.5Z" fill="url(#dd1)" />
    </g>
    <defs>
        <linearGradient id="bb1" x1="2.858" y1="151.044" x2="705.503" y2="220.258" gradientUnits="userSpaceOnUse">
            <stop stop-color="#C0EECA" />
            <stop offset="1" stop-color="#8EBFFF" />
        </linearGradient>
        <linearGradient id="cc1" x1="2.858" y1="151.044" x2="705.503" y2="220.258" gradientUnits="userSpaceOnUse">
            <stop stop-color="#C0EECA" />
            <stop offset="1" stop-color="#8EBFFF" />
        </linearGradient>
        <linearGradient id="dd1" x1="2.858" y1="151.044" x2="705.503" y2="220.258" gradientUnits="userSpaceOnUse">
            <stop stop-color="#C0EECA" />
            <stop offset="1" stop-color="#8EBFFF" />
        </linearGradient>
        <filter id="aa1" x="-7.959" y="-22.456" width="573.872" height="538.456" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dy="20" />
            <feGaussianBlur stdDeviation="10" />
            <feComposite in2="hardAlpha" operator="out" />
            <feColorMatrix values="0 0 0 0 0.0745098 0 0 0 0 0.278431 0 0 0 0 0.117647 0 0 0 0.2 0" />
            <feBlend in2="BackgroundImageFix" result="effect1_dropShadow_68_1366" />
            <feBlend in="SourceGraphic" in2="effect1_dropShadow_68_1366" result="shape" />
            <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dx="-28.608" dy="-21.456" />
            <feGaussianBlur stdDeviation="35.761" />
            <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
            <feColorMatrix values="0 0 0 0 0.0745098 0 0 0 0 0.278431 0 0 0 0 0.117647 0 0 0 1 0" />
            <feBlend in2="shape" result="effect2_innerShadow_68_1366" />
            <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dx="42.913" dy="14.304" />
            <feGaussianBlur stdDeviation="53.641" />
            <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
            <feColorMatrix values="0 0 0 0 0.558333 0 0 0 0 0.747619 0 0 0 0 1 0 0 0 1 0" />
            <feBlend in2="effect2_innerShadow_68_1366" result="effect3_innerShadow_68_1366" />
        </filter>
    </defs>
</svg>