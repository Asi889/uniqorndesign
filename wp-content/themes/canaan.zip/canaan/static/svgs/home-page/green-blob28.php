<?php
?>

<svg width="97" height="91" fill="none" xmlns="http://www.w3.org/2000/svg">
  <g filter="url(#aw)">
    <path d="M20.735 21.344C20.735 5.242 31.07.5 47.171.5s28.627 9.762 29.682 20.844C77.863 31.953 65.993 50.5 49.891 50.5S20.735 37.447 20.735 21.344Z" fill="url(#bw)"/>
  </g>
  <defs>
    <linearGradient id="bw" x1="78.903" y1="34.563" x2=".431" y2="26.316" gradientUnits="userSpaceOnUse">
      <stop stop-color="#81DD95"/>
      <stop offset="1" stop-color="#8EBFFF"/>
    </linearGradient>
    <filter id="aw" x="-7.873" y="-20.956" width="104.786" height="111.456" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
      <feFlood flood-opacity="0" result="BackgroundImageFix"/>
      <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
      <feOffset dy="20"/>
      <feGaussianBlur stdDeviation="10"/>
      <feComposite in2="hardAlpha" operator="out"/>
      <feColorMatrix values="0 0 0 0 0.0745098 0 0 0 0 0.278431 0 0 0 0 0.117647 0 0 0 0.2 0"/>
      <feBlend in2="BackgroundImageFix" result="effect1_dropShadow_68_1365"/>
      <feBlend in="SourceGraphic" in2="effect1_dropShadow_68_1365" result="shape"/>
      <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
      <feOffset dx="-28.608" dy="-21.456"/>
      <feGaussianBlur stdDeviation="35.761"/>
      <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
      <feColorMatrix values="0 0 0 0 0.0745098 0 0 0 0 0.278431 0 0 0 0 0.117647 0 0 0 0.4 0"/>
      <feBlend in2="shape" result="effect2_innerShadow_68_1365"/>
      <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
      <feOffset dx="20" dy="20"/>
      <feGaussianBlur stdDeviation="20"/>
      <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
      <feColorMatrix values="0 0 0 0 0.752941 0 0 0 0 0.933333 0 0 0 0 0.792157 0 0 0 1 0"/>
      <feBlend in2="effect2_innerShadow_68_1365" result="effect3_innerShadow_68_1365"/>
    </filter>
  </defs>
</svg>