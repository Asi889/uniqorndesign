<?php
?>

<svg width="375" height="86" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M-1 13.5C-1.63-1.01 0 1 0 1h374.87v49.608S275.665 86 200.539 86C159.704 86 34.814 69.987-2 32.5c-19.044-19.392 1.5-7.5 1-19Z" fill="url(#a)" />
    <defs>
        <linearGradient id="a" x1="-23.742" y1="58.876" x2="437.385" y2="-136.254" gradientUnits="userSpaceOnUse">
            <stop stop-color="#C0EECA" />
            <stop offset="1" stop-color="#8EBFFF" />
        </linearGradient>
    </defs>
</svg>