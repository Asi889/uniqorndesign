<?php
?>

<svg width="155" height="230" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g opacity=".6" filter="url(#at)">
        <path d="M232.913 110.5c0 61.027-39.162 79-100.19 79-61.027 0-108.498-37-112.496-79C16.4 70.293 61.386 0 122.413 0c61.028 0 110.5 49.472 110.5 110.5Z" fill="url(#bt)" />
    </g>
    <defs>
        <linearGradient id="bt" x1="12.459" y1="60.403" x2="309.869" y2="91.658" gradientUnits="userSpaceOnUse">
            <stop stop-color="#C0EECA" />
            <stop offset="1" stop-color="#8EBFFF" />
        </linearGradient>
        <filter id="at" x="-8.608" y="-21.456" width="284.434" height="250.956" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dy="20" />
            <feGaussianBlur stdDeviation="10" />
            <feComposite in2="hardAlpha" operator="out" />
            <feColorMatrix values="0 0 0 0 0.0745098 0 0 0 0 0.278431 0 0 0 0 0.117647 0 0 0 0.2 0" />
            <feBlend in2="BackgroundImageFix" result="effect1_dropShadow_68_1367" />
            <feBlend in="SourceGraphic" in2="effect1_dropShadow_68_1367" result="shape" />
            <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dx="-28.608" dy="-21.456" />
            <feGaussianBlur stdDeviation="35.761" />
            <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
            <feColorMatrix values="0 0 0 0 0.0745098 0 0 0 0 0.278431 0 0 0 0 0.117647 0 0 0 1 0" />
            <feBlend in2="shape" result="effect2_innerShadow_68_1367" />
            <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dx="42.913" dy="14.304" />
            <feGaussianBlur stdDeviation="53.641" />
            <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
            <feColorMatrix values="0 0 0 0 0.558333 0 0 0 0 0.747619 0 0 0 0 1 0 0 0 1 0" />
            <feBlend in2="effect2_innerShadow_68_1367" result="effect3_innerShadow_68_1367" />
        </filter>
    </defs>
</svg>