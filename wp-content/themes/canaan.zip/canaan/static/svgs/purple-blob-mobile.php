<?php
?>

<svg class="w-full"  height="34" fill="none" xmlns="http://www.w3.org/2000/svg">
  <path class="w-full" fill="url(#a)" fill-opacity=".4" d="M0 1h375v32H0z"/>
  <path d="M-3.5 30C-14.179 33.358 0 33 0 33h375V16.634S242.287-5.576 165 2.5c-38.545 4.028-53.362 17.715-92 19-20.115.669-56.54 2.222-76.5 8.5Z" fill="#fff"/>
  <defs>
    <linearGradient id="a" x1="-13.281" y1="11.2" x2="227.292" y2="274.893" gradientUnits="userSpaceOnUse">
      <stop stop-color="#E8C4FE"/>
      <stop offset="1" stop-color="#FDC3DC"/>
    </linearGradient>
  </defs>
</svg>