<?php
?>

<svg width="68" height="63" viewBox="0 0 68 63" fill="none" xmlns="http://www.w3.org/2000/svg">
<g filter="url(#filter0_dii_84_6474)">
<path d="M14.7073 14.8492C14.7073 3.72024 21.849 0.442764 32.978 0.442764C44.1069 0.442764 52.7638 7.19009 53.4928 14.8492C54.1907 22.1814 45.9871 35 34.8581 35C23.7291 35 14.7073 25.9782 14.7073 14.8492Z" fill="url(#paint0_linear_84_6474)"/>
</g>
<defs>
<filter id="filter0_dii_84_6474" x="-5.06528" y="-14.3867" width="72.4224" height="77.0325" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dy="13.8229"/>
<feGaussianBlur stdDeviation="6.91145"/>
<feComposite in2="hardAlpha" operator="out"/>
<feColorMatrix type="matrix" values="0 0 0 0 0.533333 0 0 0 0 0.0117647 0 0 0 0 0.854902 0 0 0 0.12 0"/>
<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_84_6474"/>
<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_84_6474" result="shape"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dx="-19.7726" dy="-14.8294"/>
<feGaussianBlur stdDeviation="24.7157"/>
<feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
<feColorMatrix type="matrix" values="0 0 0 0 0.533333 0 0 0 0 0.0117647 0 0 0 0 0.854902 0 0 0 0.4 0"/>
<feBlend mode="normal" in2="shape" result="effect2_innerShadow_84_6474"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dx="13.8229" dy="13.8229"/>
<feGaussianBlur stdDeviation="13.8229"/>
<feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
<feColorMatrix type="matrix" values="0 0 0 0 0.909804 0 0 0 0 0.768627 0 0 0 0 0.996078 0 0 0 1 0"/>
<feBlend mode="normal" in2="effect2_innerShadow_84_6474" result="effect3_innerShadow_84_6474"/>
</filter>
<linearGradient id="paint0_linear_84_6474" x1="54.9093" y1="23.9849" x2="0.673715" y2="18.2852" gradientUnits="userSpaceOnUse">
<stop stop-color="#E8C4FE"/>
<stop offset="1" stop-color="#FDC3DC"/>
</linearGradient>
</defs>
</svg>