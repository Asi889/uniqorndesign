<?php
?>

<svg class="block lg:hidden" width="375" height="32" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path fill="#F4FFF7" d="M0 0h375v32H0z" />
    <path d="M27 18.152C16.322 21.511 0 32 0 32h375V15.634S254.287-6.29 177 1.787c-38.545 4.027-59.862 17.598-98.5 18.883-20.115.669-31.54-8.796-51.5-2.518Z" fill="#F5F5F5" />
</svg>