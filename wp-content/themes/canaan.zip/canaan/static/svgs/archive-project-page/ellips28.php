<?php
?>



<svg class="" width="100" height="99" viewBox="0 0 100 99" fill="none" xmlns="http://www.w3.org/2000/svg">
<g filter="url(#filter0_dii_84_7461)">
<path  d="M20 24.0132C20 4.69051 31.3021 0 48.5 0C65.6979 0 78.8095 10.715 79.936 24.0132C81.0145 36.7437 68.3373 59 51.1395 59C33.9416 59 20 43.3359 20 24.0132Z" fill="url(#paint0_linear_84_7461)"/>
</g>
<defs>
<filter id="filter0_dii_84_7461" x="-8.60842" y="-21.4563" width="108.608" height="120.456" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dy="20"/>
<feGaussianBlur stdDeviation="10"/>
<feComposite in2="hardAlpha" operator="out"/>
<feColorMatrix type="matrix" values="0 0 0 0 0.533333 0 0 0 0 0.0117647 0 0 0 0 0.854902 0 0 0 0.12 0"/>
<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_84_7461"/>
<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_84_7461" result="shape"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dx="-28.6084" dy="-21.4563"/>
<feGaussianBlur stdDeviation="35.7605"/>
<feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
<feColorMatrix type="matrix" values="0 0 0 0 0.533333 0 0 0 0 0.0117647 0 0 0 0 0.854902 0 0 0 0.4 0"/>
<feBlend mode="normal" in2="shape" result="effect2_innerShadow_84_7461"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset dx="20" dy="20"/>
<feGaussianBlur stdDeviation="20"/>
<feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1"/>
<feColorMatrix type="matrix" values="0 0 0 0 0.909804 0 0 0 0 0.768627 0 0 0 0 0.996078 0 0 0 1 0"/>
<feBlend mode="normal" in2="effect2_innerShadow_84_7461" result="effect3_innerShadow_84_7461"/>
</filter>
<linearGradient id="paint0_linear_84_7461" x1="82.125" y1="40.1938" x2="-1.8523" y2="32.2059" gradientUnits="userSpaceOnUse">
<stop stop-color="#E8C4FE"/>
<stop offset="1" stop-color="#FDC3DC"/>
</linearGradient>
</defs>
</svg>