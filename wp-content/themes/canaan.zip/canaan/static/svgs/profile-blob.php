<?php
// echo get_site_static().'/svgs/the-rock.jpg';
// die;
?>



<svg width="159" height="160" fill="none" xmlns="http://www.w3.org/2000/svg">

    <path opacity="" d="M158.439 99.146c-1.372 12.361-6.403 23.062-15.092 32.104-8.69 9.042-18.465 16.424-29.327 22.147-10.862 5.723-22.296 7.726-34.301 6.009-12.005-1.717-23.268-4.979-33.787-9.786-10.519-4.807-19.494-11.789-26.926-20.945-7.432-9.156-12.748-19.457-15.95-30.903C-.145 86.327-.83 74.538.998 62.406c1.83-12.132 6.975-22.605 15.436-31.418 8.46-8.813 18.122-15.394 28.984-19.743C56.28 6.895 67.77 3.462 79.89.945c12.12-2.519 23.096 0 32.929 7.553 9.833 7.554 18.408 15.795 25.726 24.722 7.317 8.928 12.805 19.057 16.464 30.388 3.659 11.33 4.802 23.177 3.43 35.538Z" fill="url(#img1)" />
    <defs>
        <pattern class="" id="img1" patternContentUnits="objectBoundingBox"  width="100%" height="100%" preserveAspectRatio="xMidYMid slice" viewBox="0 0 1 1">
            <image height="1" width="1"  href="<?php echo get_site_static(); ?>/svgs/the-rock-.jpg" alt="" />
        </pattern>
    </defs>
</svg>