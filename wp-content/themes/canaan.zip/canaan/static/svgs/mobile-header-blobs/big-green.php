<?php
?>

<svg width="254" height="223" fill="none" xmlns="http://www.w3.org/2000/svg">
  <g opacity=".6" filter="url(#a-big-green)">
    <path d="M233.091 110.5c0 61.027-39.163 79-100.19 79-61.028 0-108.499-37-112.497-79C16.578 70.293 61.564 0 122.591 0s110.5 49.472 110.5 110.5Z" fill="url(#b-big-green)" />
  </g>
  <defs>
    <linearGradient id="b-big-green" x1="73.906" y1="150.687" x2="217.357" y2="149.55" gradientUnits="userSpaceOnUse">
      <stop stop-color="#268E3C" />
      <stop offset="1" stop-color="#005AD1" />
    </linearGradient>
    <filter id="a-big-green" x="-8.431" y="-21.456" width="284.434" height="250.956" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
      <feFlood flood-opacity="0" result="BackgroundImageFix" />
      <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
      <feOffset dy="20" />
      <feGaussianBlur stdDeviation="10" />
      <feComposite in2="hardAlpha" operator="out" />
      <feColorMatrix values="0 0 0 0 0.0745098 0 0 0 0 0.278431 0 0 0 0 0.117647 0 0 0 0.2 0" />
      <feBlend in2="BackgroundImageFix" result="effect1_dropShadow_79_279" />
      <feBlend in="SourceGraphic" in2="effect1_dropShadow_79_279" result="shape" />
      <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
      <feOffset dx="-28.608" dy="-21.456" />
      <feGaussianBlur stdDeviation="35.761" />
      <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
      <feColorMatrix values="0 0 0 0 0.0745098 0 0 0 0 0.278431 0 0 0 0 0.117647 0 0 0 1 0" />
      <feBlend in2="shape" result="effect2_innerShadow_79_279" />
      <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
      <feOffset dx="42.913" dy="14.304" />
      <feGaussianBlur stdDeviation="53.641" />
      <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
      <feColorMatrix values="0 0 0 0 0.558333 0 0 0 0 0.747619 0 0 0 0 1 0 0 0 1 0" />
      <feBlend in2="effect2_innerShadow_79_279" result="effect3_innerShadow_79_279" />
    </filter>
  </defs>
</svg>