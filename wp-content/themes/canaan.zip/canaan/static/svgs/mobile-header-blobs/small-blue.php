<?php
?>

<svg width="97" height="90" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g filter="url(#a-small-blue)">
        <path d="M76.178 29.156C76.178 45.258 65.844 50 49.742 50S21.115 40.237 20.06 29.156C19.05 18.547 30.92 0 47.022 0s29.156 13.053 29.156 29.156Z" fill="url(#b-small-blue)" />
    </g>
    <defs>
        <linearGradient id="b-small-blue" x1="18.01" y1="15.938" x2="96.483" y2="24.184" gradientUnits="userSpaceOnUse">
            <stop stop-color="#F9F2FF" />
            <stop offset="1" stop-color="#8EBFFF" />
        </linearGradient>
        <filter id="a-small-blue" x="-8.608" y="-21.456" width="104.786" height="111.456" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dy="20" />
            <feGaussianBlur stdDeviation="10" />
            <feComposite in2="hardAlpha" operator="out" />
            <feColorMatrix values="0 0 0 0 0 0 0 0 0 0.351786 0 0 0 0 0.820833 0 0 0 0.2 0" />
            <feBlend in2="BackgroundImageFix" result="effect1_dropShadow_84_9517" />
            <feBlend in="SourceGraphic" in2="effect1_dropShadow_84_9517" result="shape" />
            <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dx="-28.608" dy="-21.456" />
            <feGaussianBlur stdDeviation="35.761" />
            <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
            <feColorMatrix values="0 0 0 0 0 0 0 0 0 0.351786 0 0 0 0 0.820833 0 0 0 0.2 0" />
            <feBlend in2="shape" result="effect2_innerShadow_84_9517" />
            <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dx="20" dy="20" />
            <feGaussianBlur stdDeviation="20" />
            <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
            <feColorMatrix values="0 0 0 0 0.558333 0 0 0 0 0.747619 0 0 0 0 1 0 0 0 0.2 0" />
            <feBlend in2="effect2_innerShadow_84_9517" result="effect3_innerShadow_84_9517" />
        </filter>
    </defs>
</svg>