<?php
?>

<svg  xmlns="http://www.w3.org/2000/svg">
  <g opacity=".6" >
    <path d="M233.091 110.5c0 61.027-39.163 79-100.19 79-61.028 0-108.499-37-112.497-79C16.578 70.293 61.564 0 122.591 0s110.5 49.472 110.5 110.5Z" fill="url(#b)" />
  </g>
  <defs>
    <linearGradient id="b" x1="12.637" y1="60.403" x2="310.046" y2="91.658" gradientUnits="userSpaceOnUse">
      <stop stop-color="#F9F2FF" />
      <stop offset="1" stop-color="#8EBFFF" />
    </linearGradient>
    <filter id="a" x="-8.431" y="-21.456" width="100%" height="100%" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
      <feFlood flood-opacity="0" result="BackgroundImageFix" />
      <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
      <feOffset dy="20" />
      <feGaussianBlur stdDeviation="10" />
      <feComposite in2="hardAlpha" operator="out" />
      <feColorMatrix values="0 0 0 0 0.558333 0 0 0 0 0.747619 0 0 0 0 1 0 0 0 0.4 0" />
      <feBlend in2="BackgroundImageFix" result="effect1_dropShadow_84_9516" />
      <feBlend in="SourceGraphic" in2="effect1_dropShadow_84_9516" result="shape" />
      <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
      <feOffset dx="-28.608" dy="-21.456" />
      <feGaussianBlur stdDeviation="35.761" />
      <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
      <feColorMatrix values="0 0 0 0 0 0 0 0 0 0.351786 0 0 0 0 0.820833 0 0 0 1 0" />
      <feBlend in2="shape" result="effect2_innerShadow_84_9516" />
      <feColorMatrix in="SourceAlpha" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
      <feOffset dx="42.913" dy="14.304" />
      <feGaussianBlur stdDeviation="53.641" />
      <feComposite in2="hardAlpha" operator="arithmetic" k2="-1" k3="1" />
      <feColorMatrix values="0 0 0 0 0.764531 0 0 0 0 0.852946 0 0 0 0 0.970833 0 0 0 1 0" />
      <feBlend in2="effect2_innerShadow_84_9516" result="effect3_innerShadow_84_9516" />
    </filter>
  </defs>
</svg>