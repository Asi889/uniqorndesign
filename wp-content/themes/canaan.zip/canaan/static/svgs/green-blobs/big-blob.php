<?php
?>

<svg width="251" height="251" viewBox="0 0 251 251" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g filter="url(#filter0_d_68_364)">
        <path d="M190.538 133.176C189.407 143.296 185.262 152.058 178.103 159.461C170.944 166.864 162.889 172.908 153.94 177.594C144.991 182.279 135.571 183.919 125.68 182.513C115.789 181.108 106.51 178.437 97.8433 174.501C89.1768 170.566 81.7819 164.849 75.6589 157.353C69.5358 149.856 65.1554 141.422 62.5177 132.051C59.8801 122.68 59.3149 113.028 60.8221 103.095C62.3293 93.1617 66.5684 84.5874 73.5393 77.3718C80.5102 70.1561 88.4703 64.7679 97.4194 61.2069C106.369 57.646 115.836 54.8347 125.821 52.7731C135.806 50.7115 144.85 52.7731 152.951 58.9579C161.052 65.1427 168.118 71.8898 174.146 79.1991C180.175 86.5084 184.697 94.8017 187.712 104.079C190.726 113.356 191.668 123.055 190.538 133.176Z" fill="url(#paint0_linear_68_364)" />
    </g>
    <defs>
        <filter id="filter0_d_68_364" x="0" y="0" width="251" height="251" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dy="8" />
            <feGaussianBlur stdDeviation="30" />
            <feComposite in2="hardAlpha" operator="out" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.106875 0 0 0 0 0.196786 0 0 0 0 0.316667 0 0 0 0.24 0" />
            <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_68_364" />
            <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_68_364" result="shape" />
        </filter>
        <linearGradient id="paint0_linear_68_364" x1="55.3604" y1="93.7562" x2="238.765" y2="110.911" gradientUnits="userSpaceOnUse">
            <stop stop-color="#C0EECA" />
            <stop offset="1" stop-color="#8EBFFF" />
        </linearGradient>
    </defs>
</svg>
