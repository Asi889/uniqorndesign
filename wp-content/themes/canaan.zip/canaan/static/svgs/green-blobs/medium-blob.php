<?php
?>

<svg width="198" height="198" viewBox="0 0 198 198" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g filter="url(#filter0_d_68_366)">
        <path d="M137.725 100.334C137.052 106.36 134.584 111.576 130.321 115.984C126.058 120.392 121.262 123.991 115.934 126.781C110.605 129.571 104.996 130.547 99.1071 129.71C93.2177 128.873 87.6929 127.283 82.5327 124.94C77.3724 122.596 72.9694 119.193 69.3236 114.729C65.6778 110.265 63.0696 105.244 61.4991 99.664C59.9286 94.0844 59.5921 88.3373 60.4895 82.4229C61.3869 76.5085 63.911 71.4032 68.0616 67.1068C72.2122 62.8105 76.9518 59.6022 82.2803 57.482C87.6087 55.3617 93.2457 53.6878 99.1912 52.4603C105.137 51.2328 110.521 52.4603 115.345 56.1429C120.169 59.8254 124.375 63.8428 127.965 68.1949C131.555 72.547 134.247 77.485 136.042 83.0088C137.837 88.5326 138.398 94.3075 137.725 100.334Z" fill="url(#paint0_linear_68_366)" />
    </g>
    <defs>
        <filter id="filter0_d_68_366" x="0" y="0" width="198" height="198" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dy="8" />
            <feGaussianBlur stdDeviation="30" />
            <feComposite in2="hardAlpha" operator="out" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.106875 0 0 0 0 0.196786 0 0 0 0 0.316667 0 0 0 0.24 0" />
            <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_68_366" />
            <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_68_366" result="shape" />
        </filter>
        <linearGradient id="paint0_linear_68_366" x1="57.2375" y1="76.8625" x2="166.44" y2="87.0767" gradientUnits="userSpaceOnUse">
            <stop stop-color="#C0EECA" />
            <stop offset="1" stop-color="#8EBFFF" />
        </linearGradient>
    </defs>
</svg>