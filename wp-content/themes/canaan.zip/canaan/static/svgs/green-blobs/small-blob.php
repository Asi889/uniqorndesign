<?php
?>

<svg width="155" height="155" viewBox="0 0 155 155" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g filter="url(#filter0_d_68_365)">
        <path d="M94.8764 73.6881C94.5744 76.3921 93.467 78.733 91.5542 80.7109C89.6414 82.6889 87.4895 84.3037 85.0985 85.5556C82.7076 86.8074 80.1907 87.2456 77.548 86.87C74.9054 86.4944 72.4263 85.7809 70.1108 84.7294C67.7953 83.6778 65.8196 82.1506 64.1837 80.1476C62.5477 78.1447 61.3774 75.8914 60.6727 73.3877C59.968 70.884 59.817 68.3052 60.2197 65.6513C60.6223 62.9974 61.7549 60.7065 63.6174 58.7787C65.4798 56.8509 67.6066 55.4113 69.9975 54.4599C72.3885 53.5085 74.918 52.7574 77.5858 52.2066C80.2536 51.6557 82.6698 52.2066 84.8343 53.859C86.9988 55.5114 88.8864 57.3141 90.4972 59.2669C92.1079 61.2198 93.316 63.4356 94.1214 65.9142C94.9268 68.3928 95.1785 70.9842 94.8764 73.6881Z" fill="url(#paint0_linear_68_365)" />
    </g>
    <defs>
        <filter id="filter0_d_68_365" x="0" y="0" width="155" height="155" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
            <feFlood flood-opacity="0" result="BackgroundImageFix" />
            <feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha" />
            <feOffset dy="8" />
            <feGaussianBlur stdDeviation="30" />
            <feComposite in2="hardAlpha" operator="out" />
            <feColorMatrix type="matrix" values="0 0 0 0 0.106875 0 0 0 0 0.196786 0 0 0 0 0.316667 0 0 0 0.24 0" />
            <feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_68_365" />
            <feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_68_365" result="shape" />
        </filter>
        <linearGradient id="paint0_linear_68_365" x1="58.7604" y1="63.1562" x2="107.762" y2="67.7395" gradientUnits="userSpaceOnUse">
            <stop stop-color="#C0EECA" />
            <stop offset="1" stop-color="#8EBFFF" />
        </linearGradient>
    </defs>
</svg>