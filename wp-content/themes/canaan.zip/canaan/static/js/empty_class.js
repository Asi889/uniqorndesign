class CHAGNE_MY_NAME{
    constructor(el, options){
        console.log(el);

    }
}

export default CHAGNE_MY_NAME;