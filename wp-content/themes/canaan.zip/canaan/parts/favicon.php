<?php
defined('ABSPATH') || die();
?>
<link rel="shortcut icon" href="<?php echo get_site_static(); ?>/images/favicon.png" />
<link rel="apple-touch-icon" href="<?php echo get_site_static(); ?>/images/icon-touch.png" />